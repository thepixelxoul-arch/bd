# SocialPanel Starter

Static GitHub Pages frontend starter.

## Included
- New Order
- Orders
- Services
- Add Funds
- Support
- Account
- Responsive sidebar
- Light/dark theme
- Demo order storage with localStorage

## GitHub Pages
Upload all files to a repository, then:
Settings → Pages → Deploy from a branch → main / root.

## Important
This is frontend-only. Login, database, payments, balance, admin panel and real order APIs require a backend.
